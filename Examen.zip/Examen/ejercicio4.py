num1 = int(input("Introduce un numero entero: "))
num2 = int(input("Introduce un numero entero: "))
num3 = int(input("Introduce un numero entero: "))
num4 = int(input("Introduce un numero entero: "))
num5 = int(input("Introduce un numero entero: "))
num6 = int(input("Introduce un numero entero: "))
num7 = int(input("Introduce un numero entero: "))
num8 = int(input("Introduce un numero entero: "))
num9 = int(input("Introduce un numero entero: "))
num10 = int(input("Introduce un numero entero: "))

suma = num1 + num2 + num3 + num4 + num5 + num6 + num7 + num8 + num9 + num10
maximo = max(num1, num2, num3, num4, num5, num6, num7, num8, num9, num10)
minimo = min(num1, num2, num3, num4, num5, num6, num7, num8, num9, num10)

print(f"La suma total es: {suma}")
print(f"La maximo es: {maximo}")
print(f"La suma total es: {minimo}")